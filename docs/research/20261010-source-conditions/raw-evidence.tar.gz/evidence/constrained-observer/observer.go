package main

func ObservedCondition(input int64) bool {
	var outside = ((input < 0) || (255 < input))
	var inside = ((0 <= input) && (input <= 255))
	_ = inside
	return outside

}

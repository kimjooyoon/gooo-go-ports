module byteguard-experiment

go 1.27.2

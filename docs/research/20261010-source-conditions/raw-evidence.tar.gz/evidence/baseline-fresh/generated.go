package main

//gooo:generated:start id="byteguard://activity/main" kind="activity"
func GoooComposedActivity0(input int64) int64 {
	return GoooComposedActivity0Call0(input)
}
func GoooComposedActivity0Call0(input int64) int64 {
	var outside = ((input < 0) || (255 < input))
	_ = outside
	var inside = ((0 <= input) && (input <= 255))
	if inside {
		return input
	} else {
		return -1
	}
}

//gooo:generated:end id="byteguard://activity/main" kind="activity"
